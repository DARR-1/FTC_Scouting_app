"""Provide the current Flet version."""

# this value will be replaced by CI
version = "0.22.1"
