"""Provide the current Flet version."""

import flet_core.version

version = flet_core.version.version
